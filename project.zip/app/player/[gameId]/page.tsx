'use client';

import { useEffect, useState, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageSquare, Send, Eye, EyeOff, Users, MapPin, 
  ScrollText, Vote as VoteIcon, Clock, Skull, Search
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GameData, Player, Message, Clue } from '@/types';
import { PHASE_LABELS, getPhaseDescription } from '@/lib/game-utils';

export default function PlayerView() {
  const params = useParams();
  const router = useRouter();
  const gameId = params.gameId as string;
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [game, setGame] = useState<GameData | null>(null);
  const [player, setPlayer] = useState<Player | null>(null);
  const [role, setRole] = useState<any>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [clues, setClues] = useState<Clue[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [activeTab, setActiveTab] = useState<'chat' | 'role' | 'clues' | 'players'>('chat');
  const [messageInput, setMessageInput] = useState('');
  const [selectedDM, setSelectedDM] = useState<string | null>(null);
  const [showSecrets, setShowSecrets] = useState(false);
  const [accusedPlayer, setAccusedPlayer] = useState<string>('');

  useEffect(() => {
    if (!gameId) return;

    const playerId = localStorage.getItem(`player_${gameId}`);
    if (!playerId) {
      router.push(`/game/${gameId}`);
      return;
    }

    loadGameData(playerId);
    setupRealtimeSubscriptions(playerId);
  }, [gameId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadGameData = async (playerId: string) => {
    try {
      const { data: gameData } = await supabase
        .from('games')
        .select('*')
        .eq('id', gameId)
        .single();

      const { data: playerData } = await supabase
        .from('players')
        .select('*')
        .eq('id', playerId)
        .single();

      const { data: playersData } = await supabase
        .from('players')
        .select('*')
        .eq('game_id', gameId);

      const { data: messagesData } = await supabase
        .from('messages')
        .select('*')
        .eq('game_id', gameId)
        .or(`recipient_id.is.null,recipient_id.eq.${playerId},sender_id.eq.${playerId}`)
        .order('created_at', { ascending: true });

      const { data: cluesData } = await supabase
        .from('clues')
        .select('*')
        .eq('game_id', gameId)
        .eq('revealed', true);

      setGame(gameData);
      setPlayer(playerData);
      setPlayers(playersData || []);
      setMessages(messagesData || []);
      setClues(cluesData || []);

      if (playerData?.role_id) {
        const { data: roleData } = await supabase
          .from('roles')
          .select('*')
          .eq('id', playerData.role_id)
          .single();
        setRole(roleData);
      }

      setLoading(false);
    } catch (error) {
      console.error('Error loading game:', error);
      setLoading(false);
    }
  };

  const setupRealtimeSubscriptions = (playerId: string) => {
    const channel = supabase
      .channel(`player-${playerId}`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'games', filter: `id=eq.${gameId}` },
        () => loadGameData(playerId)
      )
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `game_id=eq.${gameId}` },
        () => loadGameData(playerId)
      )
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'clues', filter: `game_id=eq.${gameId}` },
        () => loadGameData(playerId)
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !player) return;

    await supabase
      .from('messages')
      .insert({
        game_id: gameId,
        sender_id: player.id,
        recipient_id: selectedDM,
        content: messageInput.trim(),
        is_system_message: false,
      });

    setMessageInput('');
  };

  const submitAccusation = async () => {
    if (!accusedPlayer || !player) return;

    await supabase
      .from('votes')
      .insert({
        game_id: gameId,
        voter_id: player.id,
        accused_id: accusedPlayer,
        round: game?.current_round || 1,
      });

    // Send system message
    const accused = players.find(p => p.id === accusedPlayer);
    await supabase
      .from('messages')
      .insert({
        game_id: gameId,
        sender_id: player.id,
        recipient_id: null,
        content: `${player.name} has accused ${accused?.name}!`,
        is_system_message: true,
      });

    setAccusedPlayer('');
    if (player) loadGameData(player.id);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  if (!game || !player) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-parchment/70">Game not found</p>
        </div>
      </div>
    );
  }

  const otherPlayers = players.filter(p => p.id !== player.id && !p.is_host);
  const revealedClues = clues.filter(c => c.revealed);
  const displayMessages = selectedDM
    ? messages.filter(m => 
        (m.sender_id === player.id && m.recipient_id === selectedDM) ||
        (m.sender_id === selectedDM && m.recipient_id === player.id)
      )
    : messages.filter(m => m.recipient_id === null);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="bg-ink/80 backdrop-blur-lg border-b border-gold/20 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold text-gold">
                {game.name}
              </h1>
              <div className="flex items-center gap-3 mt-1">
                <span className="badge badge-innocent text-xs">
                  {PHASE_LABELS[game.phase]}
                </span>
                <span className="text-parchment/60 text-sm">
                  {player.name}
                </span>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-parchment/70 text-sm">{getPhaseDescription(game.phase)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        {/* Left Sidebar - Tabs */}
        <div className="md:w-64 bg-ink/40 border-r border-gold/10 p-4">
          <div className="space-y-2">
            {[
              { id: 'chat', label: 'Chat', icon: MessageSquare },
              { id: 'role', label: 'Your Role', icon: ScrollText },
              { id: 'clues', label: 'Clues', icon: Search, badge: revealedClues.length },
              { id: 'players', label: 'Suspects', icon: Users, badge: otherPlayers.length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === tab.id
                    ? 'bg-gold/20 text-gold border border-gold/40'
                    : 'hover:bg-parchment/5 text-parchment/70'
                }`}
              >
                <tab.icon size={20} />
                <span className="flex-1 text-left">{tab.label}</span>
                {tab.badge !== undefined && (
                  <span className="bg-blood/30 text-blood px-2 py-1 rounded-full text-xs font-semibold">
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          <AnimatePresence mode="wait">
            {activeTab === 'chat' && (
              <ChatTab
                messages={displayMessages}
                messageInput={messageInput}
                setMessageInput={setMessageInput}
                sendMessage={sendMessage}
                selectedDM={selectedDM}
                setSelectedDM={setSelectedDM}
                otherPlayers={otherPlayers}
                currentPlayer={player}
                messagesEndRef={messagesEndRef}
              />
            )}

            {activeTab === 'role' && role && (
              <RoleTab
                role={role}
                showSecrets={showSecrets}
                setShowSecrets={setShowSecrets}
              />
            )}

            {activeTab === 'clues' && (
              <CluesTab
                clues={revealedClues}
                locations={game.locations}
              />
            )}

            {activeTab === 'players' && (
              <PlayersTab
                players={otherPlayers}
                currentPlayer={player}
                accusedPlayer={accusedPlayer}
                setAccusedPlayer={setAccusedPlayer}
                submitAccusation={submitAccusation}
                gamePhase={game.phase}
              />
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

// Chat Tab Component
function ChatTab({
  messages, messageInput, setMessageInput, sendMessage,
  selectedDM, setSelectedDM, otherPlayers, currentPlayer, messagesEndRef
}: any) {
  return (
    <motion.div
      key="chat"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex-1 flex flex-col"
    >
      {/* DM Selector */}
      <div className="bg-ink/40 border-b border-gold/10 p-4">
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedDM(null)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              !selectedDM
                ? 'bg-gold/20 text-gold border border-gold/40'
                : 'bg-parchment/5 text-parchment/70 hover:bg-parchment/10'
            }`}
          >
            Group Chat
          </button>
          {otherPlayers.map((p: Player) => (
            <button
              key={p.id}
              onClick={() => setSelectedDM(p.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                selectedDM === p.id
                  ? 'bg-gold/20 text-gold border border-gold/40'
                  : 'bg-parchment/5 text-parchment/70 hover:bg-parchment/10'
              }`}
            >
              <span className="mr-2">{p.avatar}</span>
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg: Message) => {
          const sender = otherPlayers.find((p: Player) => p.id === msg.senderId) || currentPlayer;
          const isOwn = msg.senderId === currentPlayer.id;
          const isSystem = msg.isSystemMessage;

          if (isSystem) {
            return (
              <div key={msg.id} className="text-center">
                <span className="inline-block bg-gold/10 text-gold px-4 py-2 rounded-full text-sm">
                  {msg.content}
                </span>
              </div>
            );
          }

          return (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs md:max-w-md ${isOwn ? 'order-2' : 'order-1'}`}>
                <div className="flex items-center gap-2 mb-1">
                  {!isOwn && <span className="text-xl">{sender?.avatar}</span>}
                  <span className="text-sm text-parchment/60">{sender?.name}</span>
                </div>
                <div className={`p-3 rounded-lg ${
                  isOwn 
                    ? 'bg-gold/20 text-parchment' 
                    : 'bg-ink/60 text-parchment/90'
                }`}>
                  {msg.content}
                </div>
              </div>
            </motion.div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <form onSubmit={sendMessage} className="bg-ink/40 border-t border-gold/10 p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            placeholder={selectedDM ? 'Send a private message...' : 'Send a message to everyone...'}
            className="input-mystery flex-1"
          />
          <button
            type="submit"
            disabled={!messageInput.trim()}
            className="btn-primary px-6 disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </motion.div>
  );
}

// Role Tab Component
function RoleTab({ role, showSecrets, setShowSecrets }: any) {
  return (
    <motion.div
      key="role"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex-1 overflow-y-auto p-6"
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="mystery-card">
          <div className="flex items-start gap-4 mb-6">
            <span className="text-6xl">{role.avatar}</span>
            <div className="flex-1">
              <h2 className="font-display text-3xl font-bold mb-2">{role.name}</h2>
              <p className="text-xl text-gold mb-1">{role.role}</p>
              <p className="text-parchment/70 italic">{role.personality}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="font-display text-xl font-semibold mb-2 text-gold">Your Alibi</h3>
              <p className="text-parchment/80">{role.alibi}</p>
            </div>

            {role.motive && (
              <div>
                <h3 className="font-display text-xl font-semibold mb-2 text-blood">Your Motive</h3>
                <p className="text-parchment/80">{role.motive}</p>
              </div>
            )}
          </div>
        </div>

        <div className="mystery-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-2xl font-semibold text-gold">Your Secrets</h3>
            <button
              onClick={() => setShowSecrets(!showSecrets)}
              className="btn-secondary flex items-center gap-2"
            >
              {showSecrets ? <EyeOff size={18} /> : <Eye size={18} />}
              {showSecrets ? 'Hide' : 'Reveal'}
            </button>
          </div>

          {showSecrets ? (
            <div className="space-y-3">
              {role.secrets.map((secret: string, i: number) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="p-4 bg-blood/10 border border-blood/30 rounded-lg"
                >
                  <p className="flex items-start gap-3">
                    <Skull size={20} className="flex-shrink-0 mt-1 text-blood" />
                    <span>{secret}</span>
                  </p>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-parchment/50">
              <Skull size={48} className="mx-auto mb-3 opacity-30" />
              <p>Click "Reveal" to see your secrets</p>
              <p className="text-sm mt-2">Keep these hidden from other players!</p>
            </div>
          )}
        </div>

        {role.is_killer && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mystery-card bg-blood/20 border-blood/50"
          >
            <div className="text-center py-6">
              <Skull size={64} className="mx-auto mb-4 text-blood" />
              <h3 className="font-display text-3xl font-bold text-blood mb-2">
                You Are The Killer
              </h3>
              <p className="text-parchment/80">
                Your goal is to avoid suspicion and deflect blame onto others.
                Be convincing. Stay calm. Don't get caught.
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

// Clues Tab Component
function CluesTab({ clues, locations }: any) {
  return (
    <motion.div
      key="clues"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex-1 overflow-y-auto p-6"
    >
      <div className="max-w-4xl mx-auto">
        <h2 className="font-display text-3xl font-bold mb-6">Discovered Clues</h2>

        {clues.length === 0 ? (
          <div className="mystery-card text-center py-12">
            <Search size={64} className="mx-auto mb-4 text-gold/30" />
            <p className="text-xl text-parchment/60">No clues discovered yet...</p>
            <p className="text-parchment/50 mt-2">Wait for the investigation phase</p>
          </div>
        ) : (
          <div className="space-y-4">
            {clues.map((clue: Clue, i: number) => (
              <motion.div
                key={clue.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="mystery-card"
              >
                <div className="flex items-start gap-4">
                  <MapPin size={24} className="text-gold flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <p className="text-gold font-semibold mb-2">{clue.location}</p>
                    <p className="text-parchment/90 text-lg">{clue.text}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="mt-8 mystery-card">
          <h3 className="font-display text-xl font-semibold mb-4 text-gold">Locations</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {locations.map((location: string, i: number) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className="p-3 bg-ink/40 border border-gold/20 rounded-lg text-center"
              >
                <MapPin size={20} className="mx-auto mb-1 text-gold" />
                <p className="text-sm">{location}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Players Tab Component
function PlayersTab({ 
  players, currentPlayer, accusedPlayer, setAccusedPlayer, 
  submitAccusation, gamePhase 
}: any) {
  const canAccuse = gamePhase === 'accusations' || gamePhase === 'voting';

  return (
    <motion.div
      key="players"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex-1 overflow-y-auto p-6"
    >
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-3xl font-bold">Suspects</h2>
          {canAccuse && (
            <span className="badge badge-killer">Accusation Phase</span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {players.map((player: Player, i: number) => (
            <motion.div
              key={player.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="mystery-card"
            >
              <div className="flex items-start gap-4">
                <span className="text-5xl">{player.avatar}</span>
                <div className="flex-1">
                  <h3 className="font-display text-2xl font-semibold mb-1">{player.name}</h3>
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-parchment/60">Suspicion</span>
                        <span className="text-sm font-semibold">{player.suspicion_level}%</span>
                      </div>
                      <div className="w-full bg-ink/50 rounded-full h-2">
                        <motion.div
                          className="bg-blood h-full rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${player.suspicion_level}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  {canAccuse && (
                    <button
                      onClick={() => {
                        setAccusedPlayer(player.id);
                        setTimeout(submitAccusation, 100);
                      }}
                      disabled={accusedPlayer === player.id}
                      className="btn-primary w-full text-sm py-2 disabled:opacity-50"
                    >
                      <VoteIcon size={16} className="inline mr-2" />
                      {accusedPlayer === player.id ? 'Accused!' : 'Accuse'}
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {canAccuse && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-6 mystery-card bg-blood/10 border-blood/30"
          >
            <p className="text-center text-parchment/80">
              <strong>Make your accusation wisely.</strong> You only get one vote per round.
            </p>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
