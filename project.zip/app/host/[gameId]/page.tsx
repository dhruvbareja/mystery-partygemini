'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, Pause, Eye, Zap, AlertTriangle, Users, MessageSquare,
  Activity, Clock, Skull, Share2, Copy, Check
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GameData, Player, Clue, Message, Vote, GamePhase } from '@/types';
import { PHASE_LABELS, formatTimeRemaining } from '@/lib/game-utils';

export default function HostDashboard() {
  const params = useParams();
  const router = useRouter();
  const gameId = params.gameId as string;

  const [game, setGame] = useState<GameData | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [clues, setClues] = useState<Clue[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [votes, setVotes] = useState<Vote[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(300);

  useEffect(() => {
    if (!gameId) return;

    // Verify host
    const hostId = localStorage.getItem(`host_${gameId}`);
    if (!hostId) {
      router.push(`/game/${gameId}`);
      return;
    }

    loadGameData();
    setupRealtimeSubscriptions();
  }, [gameId]);

  const loadGameData = async () => {
    try {
      const { data: gameData } = await supabase
        .from('games')
        .select('*')
        .eq('id', gameId)
        .single();

      const { data: playersData } = await supabase
        .from('players')
        .select('*')
        .eq('game_id', gameId);

      const { data: cluesData } = await supabase
        .from('clues')
        .select('*')
        .eq('game_id', gameId);

      const { data: messagesData } = await supabase
        .from('messages')
        .select('*')
        .eq('game_id', gameId)
        .order('created_at', { ascending: false })
        .limit(50);

      const { data: votesData } = await supabase
        .from('votes')
        .select('*')
        .eq('game_id', gameId);

      setGame(gameData);
      setPlayers(playersData || []);
      setClues(cluesData || []);
      setMessages(messagesData || []);
      setVotes(votesData || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading game:', error);
      setLoading(false);
    }
  };

  const setupRealtimeSubscriptions = () => {
    const playersChannel = supabase
      .channel(`game-${gameId}-players`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'players', filter: `game_id=eq.${gameId}` },
        () => loadGameData()
      )
      .subscribe();

    const messagesChannel = supabase
      .channel(`game-${gameId}-messages`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `game_id=eq.${gameId}` },
        () => loadGameData()
      )
      .subscribe();

    return () => {
      playersChannel.unsubscribe();
      messagesChannel.unsubscribe();
    };
  };

  const startGame = async () => {
    if (!game) return;

    // Assign roles to players
    const nonHostPlayers = players.filter(p => !p.is_host);
    const { data: roles } = await supabase
      .from('roles')
      .select('*')
      .eq('game_id', gameId);

    if (roles && nonHostPlayers.length === roles.length) {
      for (let i = 0; i < nonHostPlayers.length; i++) {
        await supabase
          .from('players')
          .update({ role_id: roles[i].id })
          .eq('id', nonHostPlayers[i].id);
      }
    }

    await supabase
      .from('games')
      .update({ 
        phase: 'role_reveal',
        started_at: new Date().toISOString()
      })
      .eq('id', gameId);

    loadGameData();
  };

  const advancePhase = async () => {
    if (!game) return;

    const phases: GamePhase[] = [
      'lobby', 'role_reveal', 'intro_round', 'investigation',
      'clue_drop', 'accusations', 'voting', 'reveal', 'finished'
    ];
    
    const currentIndex = phases.indexOf(game.phase);
    const nextPhase = phases[currentIndex + 1] || 'finished';

    await supabase
      .from('games')
      .update({ phase: nextPhase })
      .eq('id', gameId);

    loadGameData();
  };

  const revealClue = async (clueId: string) => {
    await supabase
      .from('clues')
      .update({ 
        revealed: true,
        revealed_at: new Date().toISOString()
      })
      .eq('id', clueId);

    // Send system message
    const clue = clues.find(c => c.id === clueId);
    if (clue) {
      await supabase
        .from('messages')
        .insert({
          game_id: gameId,
          sender_id: game?.host_id || '',
          recipient_id: null,
          content: `🔍 New Clue Discovered in ${clue.location}: ${clue.text}`,
          is_system_message: true,
        });
    }

    loadGameData();
  };

  const copyJoinLink = () => {
    const url = `${window.location.origin}/game/${gameId}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-parchment/70">Game not found</p>
        </div>
      </div>
    );
  }

  const nonHostPlayers = players.filter(p => !p.is_host);
  const revealedClues = clues.filter(c => c.revealed);
  const unrevealedClues = clues.filter(c => !c.revealed);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
            <div>
              <h1 className="font-display text-4xl md:text-5xl font-bold glow-text mb-2">
                {game.name}
              </h1>
              <div className="flex items-center gap-4 text-parchment/70">
                <span className="badge badge-killer">{PHASE_LABELS[game.phase]}</span>
                <span>Game: {gameId}</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button onClick={copyJoinLink} className="btn-secondary flex items-center gap-2">
                {copied ? <Check size={18} /> : <Copy size={18} />}
                {copied ? 'Copied!' : 'Share Link'}
              </button>
            </div>
          </div>
        </div>

        {/* Game Controls */}
        <motion.div 
          className="mystery-card mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h2 className="font-display text-2xl font-semibold mb-4 text-gold flex items-center gap-2">
            <Zap size={24} />
            Host Controls
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {game.phase === 'lobby' ? (
              <button
                onClick={startGame}
                disabled={nonHostPlayers.length < 2}
                className="btn-primary flex items-center justify-center gap-2"
              >
                <Play size={18} />
                Start Game
              </button>
            ) : (
              <>
                <button
                  onClick={advancePhase}
                  className="btn-primary flex items-center justify-center gap-2"
                >
                  <Play size={18} />
                  Next Phase
                </button>
                
                <button className="btn-secondary flex items-center justify-center gap-2">
                  <Pause size={18} />
                  Pause
                </button>
                
                <button className="btn-secondary flex items-center justify-center gap-2">
                  <Eye size={18} />
                  Peek Secret
                </button>
                
                <button className="btn-secondary flex items-center justify-center gap-2">
                  <AlertTriangle size={18} />
                  Trigger Twist
                </button>
              </>
            )}
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Players & Activity */}
          <div className="lg:col-span-2 space-y-6">
            {/* Players List */}
            <motion.div
              className="mystery-card"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2 className="font-display text-2xl font-semibold mb-4 text-gold flex items-center gap-2">
                <Users size={24} />
                Players ({nonHostPlayers.length})
              </h2>
              
              <div className="space-y-3">
                {nonHostPlayers.map((player, index) => (
                  <motion.div
                    key={player.id}
                    className="flex items-center justify-between p-3 bg-ink/30 rounded-lg border border-gold/20"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{player.avatar}</span>
                      <div>
                        <p className="font-semibold">{player.name}</p>
                        <p className="text-sm text-parchment/60">
                          {player.is_ready ? '✓ Ready' : 'Waiting...'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-sm text-parchment/70">Suspicion</p>
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-ink/50 rounded-full h-2">
                            <motion.div
                              className="bg-blood h-full rounded-full"
                              initial={{ width: 0 }}
                              animate={{ width: `${player.suspicion_level}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold">{player.suspicion_level}%</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Recent Messages */}
            <motion.div
              className="mystery-card"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="font-display text-2xl font-semibold mb-4 text-gold flex items-center gap-2">
                <MessageSquare size={24} />
                Recent Activity
              </h2>
              
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {messages.slice(0, 10).map((msg, index) => {
                  const sender = players.find(p => p.id === msg.senderId);
                  return (
                    <div key={msg.id} className="p-2 bg-ink/20 rounded text-sm">
                      <span className="font-semibold text-gold">
                        {sender?.name || 'System'}:
                      </span>{' '}
                      <span className="text-parchment/80">{msg.content}</span>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </div>

          {/* Right Column - Clues & Info */}
          <div className="space-y-6">
            {/* Clues */}
            <motion.div
              className="mystery-card"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2 className="font-display text-2xl font-semibold mb-4 text-gold">
                Clues ({revealedClues.length}/{clues.length})
              </h2>
              
              <div className="space-y-3">
                {unrevealedClues.slice(0, 3).map((clue) => (
                  <div key={clue.id} className="p-3 bg-ink/30 rounded-lg border border-gold/20">
                    <p className="text-sm mb-2 text-parchment/70">{clue.location}</p>
                    <p className="mb-3 text-sm">{clue.text}</p>
                    <button
                      onClick={() => revealClue(clue.id)}
                      className="btn-primary text-xs w-full py-2"
                    >
                      Reveal Clue
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Game Info */}
            <motion.div
              className="mystery-card"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="font-display text-2xl font-semibold mb-4 text-gold">
                Game Info
              </h2>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-parchment/60">Theme:</span>
                  <span>{game.theme}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-parchment/60">Victim:</span>
                  <span>{game.victim}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-parchment/60">Killer:</span>
                  <span className="text-blood font-semibold">{game.killer}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-parchment/60">Round:</span>
                  <span>{game.current_round}/{game.max_rounds}</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
