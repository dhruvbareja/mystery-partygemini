import { AIGenerationInput, AIGenerationOutput } from "@/types";

export async function generateMysteryGame(
  input: AIGenerationInput
): Promise<AIGenerationOutput> {

  const prompt = `
You are an API that outputs ONLY valid JSON.

Return EXACT JSON only.

{
  "story": "",
  "victim": "",
  "killer": "",
  "characters": [],
  "locations": [],
  "clues": [],
  "timeline": [],
  "twists": [],
  "evidence": [],
  "endingText": ""
}

Players: ${input.playerNames.join(", ")}
Locations: ${input.locations.join(", ")}
Theme: ${input.theme}
Notes: ${input.customNotes ?? ""}
`;

  const res = await fetch("http://localhost:11434/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "mistral",
      prompt,
      stream: false
    }),
  });

  const data = await res.json();

  const match = data.response.match(/\{[\s\S]*\}/);

  if (!match) {
    throw new Error("Model did not return JSON:\n" + data.response);
  }

  return JSON.parse(match[0]);
}