export type GamePhase = 
  | 'lobby'
  | 'role_reveal'
  | 'intro_round'
  | 'investigation'
  | 'clue_drop'
  | 'accusations'
  | 'voting'
  | 'reveal'
  | 'finished';

export type PlayerRole = {
  id: string;
  name: string;
  role: string;
  secrets: string[];
  motive: string | null;
  alibi: string;
  personality: string;
  isKiller: boolean;
  avatar: string;
};

export type Clue = {
  id: string;
  text: string;
  location: string;
  revealed: boolean;
  timestamp?: string;
};

export type Message = {
  id: string;
  gameId: string;
  senderId: string;
  recipientId: string | null; // null = group chat
  content: string;
  timestamp: string;
  isSystemMessage?: boolean;
};

export type Vote = {
  id: string;
  gameId: string;
  voterId: string;
  accusedId: string;
  round: number;
};

export type GameData = {
  id: string;
  name: string;
  hostId: string;
  phase: GamePhase;
  story: string;
  victim: string;
  killer: string;
  locations: string[];
  theme: string;
  createdAt: string;
  startedAt: string | null;
  endedAt: string | null;
  currentRound: number;
  maxRounds: number;
  revealedClues: string[];
  twists: string[];
  endingText: string;
  settings: {
    timerEnabled: boolean;
    roundDuration: number;
  };
};

export type Player = {
  id: string;
  gameId: string;
  name: string;
  avatar: string;
  roleId: string | null;
  isHost: boolean;
  isReady: boolean;
  isAlive: boolean;
  suspicionLevel: number;
  joinedAt: string;
  lastActive: string;
};

export type GameLog = {
  id: string;
  gameId: string;
  type: 'lie' | 'contradiction' | 'alliance' | 'search' | 'accusation';
  playerId: string;
  details: string;
  timestamp: string;
};

export type AIGenerationInput = {
  gameName: string;
  playerNames: string[];
  locations: string[];
  theme: string;
  customNotes?: string;
};

export type AIGenerationOutput = {
  story: string;
  victim: string;
  killer: string;
  characters: PlayerRole[];
  locations: string[];
  clues: Omit<Clue, 'id' | 'revealed'>[];
  timeline: string[];
  twists: string[];
  evidence: string[];
  endingText: string;
};
